# Overmotion - build the APK

1. Unzip this file on your computer.
2. On github.com make a new repo, then Add file > Upload files, and drag in EVERYTHING from this folder (including the .github folder if your browser lets you, and build.yml).
3. Check the repo shows .github/workflows/build.yml. If it does NOT:
   - open build.yml in the repo, click the pencil icon,
   - change the file name box to: .github/workflows/build.yml
   - click Commit changes.
4. Open the Actions tab > Build APK > Run workflow (it also runs on every push).
5. After about 5-10 minutes, open the finished run and download the Overmotion-debug-apk artifact. Unzip it to get app-debug.apk and install it on your Android phone.
